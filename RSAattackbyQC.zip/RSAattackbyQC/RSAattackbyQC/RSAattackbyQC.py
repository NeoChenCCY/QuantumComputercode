import time

from qiskit import IBMQ
#from qiskit import Aer
from qiskit.aqua import QuantumInstance
from qiskit.aqua.algorithms import Shor

My_token = '58bb53e6fcfa01faeea8a66a569ab1abb9d71bfa97d22cc32bde83565b9022fc065df63688e6ed157e520e37f6188140f9f3fdd1d11a7b24d818510ef4a55eff'
IBMQ.save_account(My_token,overwrite = True)
IBMQ.load_account()

provider = IBMQ.get_provider(hub='ibm-q', group='open', project='main')
backend = provider.get_backend('ibmq_qasm_simulator')
#backend = Aer.get_backend('qasm_simulator')

dec1 = int('0xB178525EDD8CB1BBAFDAFEC2C7CE69B9AA5463E520FB4A845AF3866231F4C928707A29F16C31AE94216D89FED7CD3D82A5B17E3BB23D7E4C6A14063095F14B9AD3D76BE1FC2BA07FFB6365516BC16ADE6DBA166A836C32FDFBF2DC01C12654AF989C8CCCC241D101763FDA0FF5EC612E2FADAEEB603C956E2F2ADF5123D56189',16)
dec2 = int('0x010001',16)

print("n = p x q ...... ")
print("n = " + str(dec1))

print("start time : %s sec " % time.process_time())  
#start = time.clock()
star = time.process_time();

factorization = Shor(dec1, dec2)
isinstance = QuantumInstance(backend, shots = 1024, skip_qobj_validation = False)
result_dict = factorization.run(isinstance)

#end = time.clock()
end = time.process_time();
print("end time : %s sec " % time.process_time())  

result = result_dict['factors']
print(result)
print("It cost " + (end - start) + " sec ")
